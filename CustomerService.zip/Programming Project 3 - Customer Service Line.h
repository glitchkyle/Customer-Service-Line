#pragma once

int main();
void ShowMenu();
